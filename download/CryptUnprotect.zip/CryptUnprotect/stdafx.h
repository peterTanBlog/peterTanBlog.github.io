#pragma once

#include "targetver.h"

#include <windows.h>
#include <shlobj.h>

#include <stdio.h>
#include <strsafe.h>

#include <vector>