#include "stdafx.h"

std::vector<unsigned char> decrypt(BYTE *input, size_t length) {
	DATA_BLOB inblob { length, input };
	DATA_BLOB outblob;

	if (!CryptUnprotectData(&inblob, NULL, NULL, NULL, NULL, CRYPTPROTECT_UI_FORBIDDEN, &outblob)) {
		throw std::runtime_error("Couldn't decrypt");
	}

	std::vector<unsigned char> output(length);
	memcpy(&output[0], outblob.pbData, outblob.cbData);

	return output;
}

int main(int argc, wchar_t* argv[])
{
	wchar_t path[MAX_PATH];

	if (!SHGetSpecialFolderPath(nullptr, path, CSIDL_APPDATA, false)) {
		puts("Couldn't SHGetSpecialFolderPath");
		return -1;
	}

	StringCchCat(path, MAX_PATH, L"/MySQL/Workbench/workbench_user_data.dat");

	HANDLE hfile = CreateFile(path, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, 0, nullptr);
	if (INVALID_HANDLE_VALUE == hfile) {
		puts("Couldn't CreateFile");
		return -1;
	}

	HANDLE hmap = CreateFileMapping(hfile, nullptr, PAGE_READONLY, 0, 0, nullptr);
	if (!hmap) {
		puts("Couldn't CreateFileMapping");
		return -1;
	}

	DWORD size = GetFileSize(hfile, nullptr);
	BYTE *mapping = static_cast<BYTE*>(MapViewOfFile(hmap, FILE_MAP_READ, 0, 0, size));
	if (!mapping) {
		puts("Couldn't MapViewOfFile");
		return -1;
	}

	std::vector<unsigned char> decrypted{ decrypt(mapping, size) };

	puts("Decrypted dump:");
	puts(reinterpret_cast<char*>(&decrypted[0]));	// yeah, hacky

	UnmapViewOfFile(mapping);
	CloseHandle(hmap);
	CloseHandle(hfile);

	return 0;
}
